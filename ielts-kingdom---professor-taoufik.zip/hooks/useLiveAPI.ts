
import { useState, useRef, useCallback, useEffect } from 'react';
import { GoogleGenAI, LiveSession, LiveServerMessage, Modality } from '@google/genai';
import { createPcmBlob, decodeAudioData, base64ToUint8Array } from '../utils/audio-utils';

interface UseLiveAPIProps {
  systemInstruction: string;
  onTranscription: (text: string, isUser: boolean) => void;
  initialMessage?: string;
}

export const useLiveAPI = ({ systemInstruction, onTranscription, initialMessage }: UseLiveAPIProps) => {
  const [isConnected, setIsConnected] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false); // AI is speaking
  const [volume, setVolume] = useState(0);

  const audioContextRef = useRef<AudioContext | null>(null);
  const inputSourceRef = useRef<MediaStreamAudioSourceNode | null>(null);
  const processorRef = useRef<ScriptProcessorNode | null>(null);
  const nextStartTimeRef = useRef<number>(0);
  const sessionRef = useRef<LiveSession | null>(null);
  const currentSessionPromiseRef = useRef<Promise<LiveSession> | null>(null);
  
  // Clean up on unmount
  useEffect(() => {
    return () => {
      disconnect();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const connect = async () => {
    try {
      if (!process.env.API_KEY) {
        console.error("API Key not found");
        return;
      }

      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      // Initialize Audio Contexts
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      audioContextRef.current = audioCtx;
      
      // Input Stream (Microphone) - 16kHz for Gemini
      const inputCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      
      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-09-2025',
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Puck' } } 
          },
          systemInstruction: systemInstruction,
          // Fix: Passing empty objects to enable transcription. 
          inputAudioTranscription: {}, 
          outputAudioTranscription: {},
        },
        callbacks: {
          onopen: () => {
            console.log("Connection established");
            setIsConnected(true);
            
            // Setup Input Processing
            const source = inputCtx.createMediaStreamSource(stream);
            inputSourceRef.current = source;
            
            // Use ScriptProcessor for raw PCM access (buffer size 4096)
            const processor = inputCtx.createScriptProcessor(4096, 1, 1);
            processorRef.current = processor;

            processor.onaudioprocess = (e) => {
              const inputData = e.inputBuffer.getChannelData(0);
              
              // Calculate volume for UI
              let sum = 0;
              for(let i=0; i<inputData.length; i++) sum += inputData[i] * inputData[i];
              setVolume(Math.sqrt(sum / inputData.length));

              const pcmBlob = createPcmBlob(inputData);
              
              // Send to Gemini
              sessionPromise.then(session => {
                  session.sendRealtimeInput({ media: pcmBlob });
              });
            };

            source.connect(processor);
            processor.connect(inputCtx.destination);
            
            // Send initial trigger message if provided
            if (initialMessage) {
               sessionPromise.then(session => {
                  // We send a text part to the model to act as the "User" starting the interaction
                  // causing the model to respond immediately.
                  (session as any).send({ 
                      parts: [{ text: initialMessage }],
                      turnComplete: true 
                  });
               });
            }
          },
          onmessage: async (msg: LiveServerMessage) => {
            // Handle Transcriptions
            if (msg.serverContent?.outputTranscription?.text) {
               onTranscription(msg.serverContent.outputTranscription.text, false);
            }
            if (msg.serverContent?.inputTranscription?.text) {
               onTranscription(msg.serverContent.inputTranscription.text, true);
            }

            // Handle Audio Output
            const base64Audio = msg.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
            if (base64Audio && audioContextRef.current) {
               setIsSpeaking(true);
               const audioData = base64ToUint8Array(base64Audio);
               
               // Ensure time sync
               nextStartTimeRef.current = Math.max(nextStartTimeRef.current, audioContextRef.current.currentTime);
               
               const audioBuffer = await decodeAudioData(audioData, audioContextRef.current, 24000);
               const source = audioContextRef.current.createBufferSource();
               source.buffer = audioBuffer;
               source.connect(audioContextRef.current.destination);
               source.start(nextStartTimeRef.current);
               
               nextStartTimeRef.current += audioBuffer.duration;
               
               source.onended = () => {
                 // Simple check: if strict time has passed, maybe stop animation
                 if (audioContextRef.current && audioContextRef.current.currentTime >= nextStartTimeRef.current) {
                    setIsSpeaking(false);
                 }
               };
            }

            // Handle Interruption
            if (msg.serverContent?.interrupted) {
               nextStartTimeRef.current = 0;
               setIsSpeaking(false);
               // In a real app, we would cancel currently playing nodes here
            }
            
            if (msg.serverContent?.turnComplete) {
                // Turn is done
                 setIsSpeaking(false);
            }
          },
          onclose: () => {
            console.log("Connection closed");
            setIsConnected(false);
          },
          onerror: (err) => {
            console.error("Connection error:", err);
            setIsConnected(false);
          }
        }
      });
      
      currentSessionPromiseRef.current = sessionPromise;
      sessionRef.current = await sessionPromise;

    } catch (e) {
      console.error("Failed to connect", e);
      setIsConnected(false);
    }
  };

  const disconnect = async () => {
    if (processorRef.current) {
        processorRef.current.disconnect();
        processorRef.current = null;
    }
    if (inputSourceRef.current) {
        inputSourceRef.current.disconnect();
        inputSourceRef.current = null;
    }
    if (audioContextRef.current) {
        audioContextRef.current.close();
        audioContextRef.current = null;
    }
    
    if (sessionRef.current) {
        (sessionRef.current as any).close?.(); 
        sessionRef.current = null;
    }
    setIsConnected(false);
    setIsSpeaking(false);
    setVolume(0);
  };

  return { connect, disconnect, isConnected, isSpeaking, volume };
};
